<?php

namespace Responsive\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;
use Mail;

class CancelController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    
	
	
	public function sangvish_showpage() {
		
		 
		 
		 
		 
		
		
		
		
		
	 
	  
      return view('cancel');
   }
   
   
   
  
	
	
	
	
	
	
	
	
	
	
}
