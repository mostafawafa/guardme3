 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- Bootstrap -->
	{!!Html::style('local/resources/assets/admin/vendors/bootstrap/dist/css/bootstrap.min.css')!!}
	{!!Html::style('local/resources/assets/admin/vendors/font-awesome/css/font-awesome.min.css')!!}
	{!!Html::style('local/resources/assets/admin/vendors/iCheck/skins/flat/green.css')!!}
	{!!Html::style('local/resources/assets/admin/vendors/bootstrap-daterangepicker/daterangepicker.css')!!}
	{!!Html::style('local/resources/assets/admin/build/css/custom.min.css')!!}
	
	{!!Html::style('local/resources/assets/admin/js/dataTables.bootstrap.min.css')!!}
	{!!Html::style('local/resources/assets/admin/js/buttons.bootstrap.min.css')!!}
	{!!Html::style('local/resources/assets/admin/js/fixedHeader.bootstrap.min.css')!!}
	{!!Html::style('local/resources/assets/admin/js/responsive.bootstrap.min.css')!!}
	{!!Html::style('local/resources/assets/admin/js/scroller.bootstrap.min.css')!!}
   